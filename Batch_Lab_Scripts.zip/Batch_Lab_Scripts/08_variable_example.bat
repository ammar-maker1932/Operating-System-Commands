@echo off
cd /d "%~dp0"

REM Store student's name
set name=Ali

REM Display variable
echo Student Name: %name%

pause
