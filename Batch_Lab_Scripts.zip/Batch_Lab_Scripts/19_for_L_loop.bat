@echo off
cd /d "%~dp0"

for /L %%i in (1,1,5) do echo %%i

pause
