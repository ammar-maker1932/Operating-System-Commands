@echo off
cd /d "%~dp0"

set /p name=Enter your name: 

if "%name%"=="Ali" echo Welcome Ali

pause
