@echo off
cd /d "%~dp0"

echo Student Name: Ali > student.txt
echo Course: Operating Systems >> student.txt
echo Lab: Batch Scripting >> student.txt

type student.txt

pause
