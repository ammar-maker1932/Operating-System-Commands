@echo off
cd /d "%~dp0"

for %%i in (1 2 3 4 5) do (
    mkdir Student%%i
)

echo Folders created successfully.

pause
