@echo off
cd /d "%~dp0"

REM Create main folders
mkdir Lectures
mkdir Assignments
mkdir Backup

echo All folders created successfully.

pause
