@echo off
cd /d "%~dp0"

REM > creates/overwrites file
echo First Line > notes.txt

REM >> appends to file
echo Second Line >> notes.txt

type notes.txt

pause
