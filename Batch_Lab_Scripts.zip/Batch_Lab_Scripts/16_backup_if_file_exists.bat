@echo off
cd /d "%~dp0"

REM Check if file exists (report.txt is included in this folder)
if exist report.txt (

    REM Create backup directory if needed
    if not exist Backup mkdir Backup

    REM Copy file
    copy report.txt Backup

    echo Backup completed.

) else (

    echo Error: report.txt was not found.

)

pause
