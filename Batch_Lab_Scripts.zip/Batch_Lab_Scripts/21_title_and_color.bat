@echo off
cd /d "%~dp0"

title OS Lab Automation
color 0A

echo Title and color changed.

pause
