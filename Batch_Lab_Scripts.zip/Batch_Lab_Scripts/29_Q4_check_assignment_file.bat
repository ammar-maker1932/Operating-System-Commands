@echo off
cd /d "%~dp0"

if exist assignment.txt (
    echo Assignment file found.
) else (
    echo Assignment file not found.
)

pause
