@echo off
cd /d "%~dp0"

for /L %%i in (1,1,10) do (
    mkdir Week%%i
)

echo All folders created.

pause
