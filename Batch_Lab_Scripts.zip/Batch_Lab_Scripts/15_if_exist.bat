@echo off
cd /d "%~dp0"

REM notes.txt banane ke liye pehle 06_redirection_demo.bat chalayen
if exist notes.txt (
    echo File found.
) else (
    echo File does not exist.
)

pause
