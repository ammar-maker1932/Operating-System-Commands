@echo off
cd /d "%~dp0"
echo Hello
pause
