@echo off
cd /d "%~dp0"

mkdir Theory
mkdir Lab
mkdir Assignment

pause
