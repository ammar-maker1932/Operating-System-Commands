@echo off
cd /d "%~dp0"

REM Take student details
set /p name=Enter student name: 
set /p reg=Enter registration number: 
set /p sem=Enter semester: 

REM Folder named after registration number
mkdir "%reg%"
cd "%reg%"

REM Save details
echo Student Name: %name% > student.txt
echo Registration Number: %reg% >> student.txt
echo Semester: %sem% >> student.txt

REM Backup
mkdir Backup
copy student.txt Backup

REM Check backup
if exist Backup\student.txt (
    echo Backup Successful
) else (
    echo Backup Failed
)

REM Directory structure
echo.
tree /f

pause
