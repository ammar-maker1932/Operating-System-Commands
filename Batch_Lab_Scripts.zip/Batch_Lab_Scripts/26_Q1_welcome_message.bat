@echo off
cd /d "%~dp0"
echo Welcome to Operating Systems Lab
pause
