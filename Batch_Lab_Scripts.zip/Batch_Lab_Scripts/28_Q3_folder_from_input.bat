@echo off
cd /d "%~dp0"

set /p folder=Enter folder name: 

mkdir "%folder%"

echo Folder created successfully.

pause
