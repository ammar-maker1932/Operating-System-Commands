@echo off
cd /d "%~dp0"

REM Create main directory
mkdir Operating_Systems

REM Enter main directory
cd Operating_Systems

REM Create subdirectories
mkdir Lectures
mkdir Assignments
mkdir Projects
mkdir Backup

REM Display structure
tree

pause
