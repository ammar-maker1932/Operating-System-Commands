@echo off
cd /d "%~dp0"

REM Ask user for name
set /p name=Enter your name: 

REM Display personalized message
echo Welcome %name% to Operating Systems Lab.

pause
