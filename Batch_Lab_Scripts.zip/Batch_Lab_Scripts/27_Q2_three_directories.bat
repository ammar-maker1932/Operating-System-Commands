@echo off
cd /d "%~dp0"

mkdir Windows
mkdir Linux
mkdir Backup

pause
