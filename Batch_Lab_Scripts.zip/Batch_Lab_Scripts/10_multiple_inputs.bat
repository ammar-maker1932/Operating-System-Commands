@echo off
cd /d "%~dp0"

set /p name=Enter your name: 
set /p reg=Enter registration number: 

echo.
echo Student Information
echo Name: %name%
echo Registration Number: %reg%

pause
