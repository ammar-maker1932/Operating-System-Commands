echo Hello Students
pause
