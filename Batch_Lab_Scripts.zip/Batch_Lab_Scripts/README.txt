Batch Lab Scripts - README
==========================
1. Zip ko pehle EXTRACT karein (zip ke andar se direct run na karein).
2. Kisi bhi .bat file par double-click karein.
3. Har script apne hi folder mein folders/files banati hai (cd /d "%~dp0").
4. Scripts aapke notes ke order mein numbered hain (01 se 33 tak).

Notes:
- 15_if_exist.bat ke liye pehle 06_redirection_demo.bat chalayen (notes.txt banane ke liye).
- 16 aur 25 ke liye report.txt is folder mein pehle se maujood hai.
- 29 ke liye assignment.txt khud bana lein (ya na banayen to "not found" dikhayega).
- Dobara run karne par "folder already exists" ka error aa sakta hai - ye normal hai.
- Practice ke liye ye folder Desktop/Documents mein rakhein, C:\Windows mein nahi.
